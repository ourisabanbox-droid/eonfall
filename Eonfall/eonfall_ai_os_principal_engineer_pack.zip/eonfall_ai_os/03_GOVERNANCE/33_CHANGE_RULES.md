# Change Rules

## Rule 1 — New systems
Every new system must define:
- inputs
- outputs
- side effects
- invariants
- persistence strategy
- reload strategy

## Rule 2 — Tick loop changes
Any change to tick order must explain:
- why this order is changing
- what systems depend on the old order
- what invariants are affected
- what new risks are introduced

## Rule 3 — New alerts
Every new alert must define:
- alert_type
- trigger condition
- payload shape
- severity
- dedup/cooldown strategy

## Rule 4 — New endpoints
Every new endpoint must define:
- read or write role
- whether it reads DB or runtime-derived persisted state
- whether it is for gameplay, debug, or both

## Rule 5 — Manual DB edits during runtime
If DB is modified manually for testing:
- restart server before relying on runtime behavior
- assume memory and DB may be divergent until reload
