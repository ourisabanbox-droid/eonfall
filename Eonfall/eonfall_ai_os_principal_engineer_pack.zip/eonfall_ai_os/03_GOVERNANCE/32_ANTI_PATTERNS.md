# Anti Patterns

## Forbidden architecture moves
- Direct gameplay mutations in HTTP handlers
- Bypassing the action queue for convenience
- Moving business logic into repositories
- Treating DB as live truth during runtime without reload
- Reordering tick systems casually

## Forbidden product moves
- Adding mechanics that do not interact with existing systems
- Solving gameplay shallowness with content quantity
- Introducing random events with no systemic grounding
- Building spectacle before consequence

## Forbidden execution moves
- Refactoring everything before proving value
- Introducing microservices too early
- Adding abstractions without current pressure
- Expanding scope before validating the current loop
