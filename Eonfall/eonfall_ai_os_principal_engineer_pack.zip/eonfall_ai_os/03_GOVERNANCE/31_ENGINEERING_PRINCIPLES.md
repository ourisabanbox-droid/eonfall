# Engineering Principles

## Principle 1 — Protect the simulation core
The engine is the heart of the game. New features should integrate with it, not bypass it.

## Principle 2 — Prefer depth over breadth
A smaller number of rich, interacting systems is better than many disconnected features.

## Principle 3 — Startup pragmatism wins
Optimize for:
- fast iteration
- clear code
- low operational complexity
- future extensibility

Not for:
- theoretical elegance with low near-term value

## Principle 4 — Build observable systems
Every important system should be inspectable via:
- API
- DB
- alerts
- deterministic test procedure

## Principle 5 — Separate logic from persistence
Repositories persist and retrieve state.
Services own gameplay logic.

## Principle 6 — Add pressure after stability
First build a stable simulation.
Then add the forces that make it interesting:
- catastrophe
- diplomacy
- conflict
- scarcity
