# Decisions Log

## D-001 — Use a tick-based engine
Status: Accepted

Reason:
- deterministic simulation
- clear ordering
- easier debugging
- strong fit for systemic gameplay

Alternatives rejected:
- request/response-only updates
- fully event-driven loose processing
- client-side authority

---

## D-002 — Keep server authoritative
Status: Accepted

Reason:
- authoritative consistency
- anti-cheat posture
- better long-term multiplayer integrity

---

## D-003 — Use modular monolith, not microservices
Status: Accepted

Reason:
- solo startup constraints
- speed of iteration
- lower operational complexity
- better cohesion while product is still evolving

---

## D-004 — Introduce a dedicated normalizer
Status: Accepted

Reason:
- systems can remain simpler
- invariants are centralized
- prevents resource overflow / negative drift
- easier debugging and future testing

Alternatives rejected:
- clamping inside every service
- relying purely on DB constraints
- ignoring invalid values until later

---

## D-005 — Persist alerts as gameplay-facing facts
Status: Accepted

Reason:
- makes the world legible
- supports debugging
- provides future UI feed
- begins the narrative layer of the simulation

---

## D-006 — Persist runtime civilization state periodically
Status: Accepted

Reason:
- API and DB must reflect simulation state
- restart continuity requires durable runtime state
- research and consumption debugging depended on this

---

## D-007 — Persist region resource stocks periodically
Status: Accepted

Reason:
- production/economy must survive restart
- building effects on production must remain durable
- region detail views must reflect meaningful state
