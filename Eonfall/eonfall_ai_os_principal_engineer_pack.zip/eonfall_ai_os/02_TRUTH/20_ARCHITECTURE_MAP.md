# Architecture Map

## Core runtime model
EONFALL uses an in-memory authoritative world simulation.

The world is loaded into memory at startup and advanced by a tick loop. Systems mutate the world state. Persistence periodically flushes selected state back to PostgreSQL.

## Tick loop
Current intended order:

1. Actions
2. Production
3. Consumption
4. Research
5. Risk
6. Catastrophes (planned)
7. Normalizer
8. Persistence

## Main architectural layers

### API layer
Responsibilities:
- accept commands
- expose read models
- validate HTTP payload shape
- never own authoritative gameplay mutation logic

### Engine layer
Responsibilities:
- advance ticks
- orchestrate systems
- maintain simulation order
- ensure system execution pipeline

### Service layer
Responsibilities:
- implement gameplay logic
- mutate in-memory world state
- emit alerts when needed

### Repository layer
Responsibilities:
- read/write PostgreSQL
- no gameplay reasoning
- persistence and retrieval only

### World model layer
Responsibilities:
- hold authoritative runtime state
- represent world, civilizations, regions, researches, buildings, alerts, etc.

## Data flow
Read:
DB -> Loader -> In-memory World -> API / Systems

Write:
API -> Action queue -> Engine systems -> Normalizer -> Persistence -> DB

## Architectural source of truth
Authoritative runtime source of truth:
- in-memory world state while server is running

Durable source of truth:
- PostgreSQL

Important:
DB is durable truth, but not automatically live truth while server is running.
