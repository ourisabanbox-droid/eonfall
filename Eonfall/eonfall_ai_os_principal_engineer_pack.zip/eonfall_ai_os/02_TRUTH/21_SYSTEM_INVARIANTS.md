# System Invariants

## Runtime invariants

### Resources
- stock >= 0
- if capacity > 0, stock <= capacity

### Civilization stats
- cohesion >= 0
- cohesion <= 100

### Region stats
- stability >= 0
- stability <= 100

## Architectural invariants
- HTTP handlers must not mutate authoritative gameplay state directly
- gameplay mutations go through engine systems and/or queued actions
- normalizer must run before persistence
- persistence should never flush obviously invalid state if normalizer can prevent it
- tick loop ordering is not casual; changes require explicit reasoning

## Alert invariants
- alerts must be understandable as gameplay-facing state
- alerts should avoid uncontrolled spam
- alerts should be persisted if they represent a meaningful world fact

## Persistence invariants
- runtime memory and DB may diverge between flushes
- after restart, loader must reconstruct enough world state to resume coherently
- a persisted gameplay mutation should survive restart

## Product invariants
- new systems must connect to existing systems
- new mechanics should increase systemic depth, not just content breadth
