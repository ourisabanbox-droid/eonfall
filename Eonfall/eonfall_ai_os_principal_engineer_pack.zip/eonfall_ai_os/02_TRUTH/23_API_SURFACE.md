# API Surface

## Existing endpoints

### Health
- `GET /health`

### World views
- `GET /worlds/:id`
- `GET /worlds/:id/map`
- `GET /worlds/:id/alerts`

### Civilization views
- `GET /worlds/:id/dashboard/:civilizationId`
- `GET /civilizations/:id/researches`

### Region views
- `GET /worlds/:id/regions/:regionId`

### Commands
- `POST /worlds/:id/actions/build`
- `POST /worlds/:id/actions/research`

## API design rules
- reads should expose useful state for gameplay and debugging
- writes should enqueue or trigger proper engine-managed mutations
- API must not become the gameplay engine
