# Domain Model

## World
Represents a running simulation instance.
Fields include:
- ID
- current tick
- phase/state
- civilization collection
- region collection
- active catastrophes (planned/partial)

## Civilization
Represents a player-controlled or system-controlled macro actor.
Fields include:
- stocks: food, energy, science, credit, materials
- cohesion
- influence
- military score
- victory score
- active/completed researches

## Region
Represents a territory on the world map.
Fields include:
- owner civilization
- biome / terrain / climate
- population
- stability
- risks (drought, revolt, etc.)
- resource stocks
- buildings

## RegionResourceStock
Represents a per-region resource state.
Fields include:
- stock
- production_rate
- consumption_rate
- capacity

## RegionBuilding
Represents an installed construction in a region.
Fields include:
- building_type
- state
- durability
- started/completed tick

## ResearchProgress
Represents civilization research state.
Fields include:
- research_type
- state
- progress
- started_tick
- completed_tick

## Alert
Represents a persisted world fact readable via API.
Fields include:
- alert_type
- severity
- title
- message
- payload
- world/civilization/region linkage

## Catastrophe
Represents a high-impact regional systemic event.
Currently planned, not fully implemented.
Examples:
- drought
- revolt
