# Data Model

## Main tables
- users
- worlds
- world_memberships
- civilizations
- regions
- region_adjacencies
- region_resource_stocks
- region_buildings
- civilization_researches
- diplomatic_pacts (future use)
- world_actions
- world_events
- world_event_participations
- world_catastrophes
- world_alerts
- world_snapshots
- world_activity_log

## Current DB role
- persistence
- restart recovery
- inspection/debugging
- API backing store for several views

## Important caution
Runtime memory is authoritative while the process runs.
Updating the DB manually does not automatically update the live in-memory world.
To ensure consistency after manual DB edits, restart the server and reload the world.
