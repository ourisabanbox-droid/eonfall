# System Interactions

## Production
Region production increases regional resource stocks and indirectly improves civilization-level stocks.

## Consumption
Consumption reduces civilization-level stocks and can reduce cohesion if key resources run out.

## Research
Research consumes science stock and increases technological progression. It depends on resource production and civilization runtime state.

## Risk
Risk accumulates pressure in regions and is intended to feed future catastrophe systems.

## Normalizer
Normalizer corrects system drift and enforces hard invariants before persistence.

## Alerts
Alerts translate systemic state changes into readable, player-facing facts.

## Buildings
Buildings modify regional capabilities, especially production rates and structural power.

## Planned future interactions
- Risk -> Catastrophe
- Research -> modifiers on production, resilience, politics
- Diplomacy -> resource sharing / conflict / alliance incentives
- Catastrophes -> economy + stability + alerts + strategic responses
