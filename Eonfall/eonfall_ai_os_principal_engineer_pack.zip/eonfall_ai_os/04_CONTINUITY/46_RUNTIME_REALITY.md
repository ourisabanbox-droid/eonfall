# Runtime Reality

## Critical runtime truth
The live world is held in memory.

This means:
- DB is durable state
- memory is live state while the server is running

## Consequence
Manual SQL edits do not automatically update the running simulation.

## Correct testing rule
If DB is modified manually for simulation-sensitive testing:
- restart the server
- let loader rebuild runtime state
- then observe engine behavior

## Debugging rule
Never assume:
DB == live runtime

Always compare:
- DB state
- API output
- expected engine behavior
