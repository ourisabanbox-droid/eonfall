# Next Steps

## Best next step
Implement catastrophes MVP:
- drought
- revolt

## Why now
- risk system already exists
- alerts already exist
- regions already carry meaningful state
- economy is already persistent
- this will add pressure, consequence, and emergent narrative

## After catastrophes
1. diplomacy MVP
2. alliance / betrayal basics
3. client UI integration
4. multi-world support
5. scaling architecture

## Priority rule
Always choose:
- systemic depth
over
- disconnected new features
