# Session Handoff Template

## Date
YYYY-MM-DD

## Session goal
What was the intended objective?

## What was implemented
List concrete code/system changes.

## What was validated
What was actually proven to work?

## What remains uncertain
List gaps, doubts, or fragile points.

## Architectural implications
Did this session change:
- architecture
- invariants
- persistence behavior
- API contracts
- ordering assumptions

## Recommended next step
What is the single best next move?

## Risks if next session is careless
What could be broken?
