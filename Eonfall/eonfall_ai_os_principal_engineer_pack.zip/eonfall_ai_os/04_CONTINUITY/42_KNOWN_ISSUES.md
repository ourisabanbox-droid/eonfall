# Known Issues

## Alerts
- Deduplication is only partially solved.
- Similar alerts may still repeat over time.
- Alert idempotence is not fully guaranteed.

## Runtime vs DB
- The world is loaded in memory once at startup.
- Manual DB edits do not affect live memory state until restart.

## Scale
- Only one world is effectively handled in-memory.
- No sharding or orchestration yet.

## Product gaps
- No catastrophes yet
- No diplomacy yet
- No warfare yet
- No player-facing UI yet

## Engineering gaps
- No robust session-by-session structured changelog automation
- No acceptance test automation yet
