# Test Playbook

## General rule
For important changes, validate through:
1. API
2. DB
3. runtime observation

## Build action test
- enqueue build
- verify world_actions state
- verify building appears in region_buildings
- verify region detail API reflects it

## Research action test
- enqueue research
- verify civilization_researches row
- verify progress increases over ticks
- verify completion state and alert

## Resource stock persistence test
- let simulation run
- query region_resource_stocks
- verify stock changes are persisted
- verify clamp to capacity works

## Alerts test
- trigger one alert scenario at a time
- inspect world_alerts table
- inspect alerts API
- verify dedup/cooldown expectations

## Runtime/DB reality test
- modify DB manually
- restart server
- verify runtime reload behavior
