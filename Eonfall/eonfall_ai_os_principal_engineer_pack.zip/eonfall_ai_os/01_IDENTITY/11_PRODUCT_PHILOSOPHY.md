# Product Philosophy

## Primary philosophy
Gameplay should emerge from systems interacting with each other, not from hardcoded scenario scripting.

## Product rules
Do:
- prefer deep interacting systems over isolated mechanics
- favor long-term consequence over short-term spectacle
- make player choices legible and meaningful
- build pressure through resource, stability, and political dynamics
- ensure new systems connect to at least two existing systems

Do not:
- add mini-games disconnected from the simulation
- script outcomes that should emerge from the world state
- choose simplicity of systems over richness of interactions
- add features only because they sound impressive

## Product test for new features
For every new feature, ask:
1. What existing systems does it interact with?
2. What strategic tension does it create?
3. What player stories can emerge from it?
4. What failure mode does it introduce?
5. Is it worth the added complexity?

## Product depth hierarchy
Preferred order:
1. systemic depth
2. world reactivity
3. player readability
4. feature breadth

## Current product direction
The project has finished the “build a stable simulation core” stage.
It now needs “inject systemic pressure and player-facing meaning” stage.
