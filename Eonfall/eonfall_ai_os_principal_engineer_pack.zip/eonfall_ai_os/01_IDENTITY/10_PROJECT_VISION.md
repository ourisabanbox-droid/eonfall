# Project Vision

## Core ambition
EONFALL aims to become an elite persistent strategy game where civilizations rise, adapt, cooperate, betray, collapse, and transform under systemic pressures.

## Design target
The game should feel:
- alive
- surprising
- strategic
- consequential
- replayable through emergence, not scripted content

## What makes EONFALL special
The central promise is not feature quantity. It is **systemic depth**.

Players should feel that:
- the world was already moving before they entered it
- their decisions matter long-term
- multiple systems interact in non-trivial ways
- the game produces stories on its own

## Long-term fantasy
A large-scale persistent world where:
- civilizations compete and cooperate
- economic specialization matters
- ecological and political mistakes have consequences
- world history emerges over time
- large player populations can coexist without flattening strategic complexity

## Product principle
EONFALL should become “the best game of all time” not by cinematic scripting, but by:
- strong simulation foundations
- high-quality systemic interactions
- meaningful strategic tradeoffs
- persistent consequences
