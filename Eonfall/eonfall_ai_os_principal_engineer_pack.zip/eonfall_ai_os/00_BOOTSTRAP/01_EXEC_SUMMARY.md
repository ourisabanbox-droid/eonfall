# EONFALL — Executive Summary

## What EONFALL is
EONFALL is a persistent strategy simulation game driven by a server-authoritative tick engine. The project is designed around systemic interactions: civilizations, regions, resources, risks, research, alerts, and later catastrophes, diplomacy, and warfare.

## Current backend status
Implemented and functioning:
- Tick engine
- Action queue and action execution
- Build action
- Research action
- Production system
- Consumption system
- Research progression
- Risk system
- Simulation normalizer
- Alerts system
- Persistence of world tick
- Persistence of civilization runtime state
- Persistence of buildings
- Persistence of researches
- Persistence of region resource stocks
- REST API for world/map/dashboard/region/researches/alerts

## Architecture
- Go monolith, modularized by domain
- PostgreSQL for persistence
- In-memory world as authoritative runtime state
- Periodic flush to DB
- HTTP API for debug + gameplay entry points

## Critical invariants
- resource stock >= 0
- resource stock <= capacity
- cohesion in [0,100]
- stability in [0,100]
- gameplay mutations must go through engine systems
- normalizer runs before persistence

## Main current weaknesses
- Alert deduplication only partially solved
- Single world loaded in memory
- No catastrophes yet
- No diplomacy yet
- No combat yet
- No client UI yet
- No multi-world orchestration or horizontal scaling yet

## Current best next step
Implement systemic pressure via catastrophes MVP:
- drought
- revolt

Reason:
the engine is now stable enough that adding pressure systems will significantly increase gameplay depth without requiring a major architectural refactor.
