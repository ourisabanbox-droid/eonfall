# Reading Order

A new AI or engineer should read these documents in this order:

1. `01_IDENTITY/10_PROJECT_VISION.md`
2. `01_IDENTITY/11_PRODUCT_PHILOSOPHY.md`
3. `02_TRUTH/20_ARCHITECTURE_MAP.md`
4. `02_TRUTH/21_SYSTEM_INVARIANTS.md`
5. `02_TRUTH/25_SYSTEM_INTERACTIONS.md`
6. `04_CONTINUITY/40_CURRENT_STATE.md`
7. `03_GOVERNANCE/30_DECISIONS_LOG.md`
8. `04_CONTINUITY/42_KNOWN_ISSUES.md`
9. `04_CONTINUITY/43_NEXT_STEPS.md`
10. `01_IDENTITY/12_AI_WORKING_RULES.md`
11. `04_CONTINUITY/46_RUNTIME_REALITY.md`

After reading, the AI should:
- summarize the project
- identify the main technical and product priorities
- state the best next execution step
