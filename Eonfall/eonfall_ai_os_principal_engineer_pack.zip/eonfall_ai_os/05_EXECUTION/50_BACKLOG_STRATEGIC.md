# Strategic Backlog

## Core systemic pressure
- catastrophes
- diplomacy
- conflict

## Player meaning
- better alerts
- actionable region state
- decisions with visible consequence

## World scale
- multi-world model
- orchestration
- scaling path

## Long-term
- alliance systems
- war systems
- large-scale emergent economics
