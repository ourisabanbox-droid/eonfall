# Release Path

## Stage 1 — Technical simulation core
Status: largely done

## Stage 2 — Pressure and emergence
Next:
- catastrophes
- diplomacy
- stronger player-facing feedback

## Stage 3 — Usable playable loop
- client UI
- player decisions become visible and meaningful

## Stage 4 — Multi-world and scale prep
- orchestration
- world lifecycle
- scaling decisions

## Stage 5 — MMO-grade execution
- horizontal scaling
- sharding / actor partitioning
- high concurrency operations
