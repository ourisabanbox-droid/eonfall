# Tactical Backlog

## Near-term
- catastrophes MVP
- stronger alert dedup
- region catastrophe visibility
- catastrophe persistence/reload

## After
- diplomacy pact creation
- basic alliance effects
- UI integration endpoints refinement
