# Acceptance Criteria

## A feature is not done unless:
- it works in runtime
- it persists correctly
- it survives restart if relevant
- it is readable via API or DB
- its main invariants are defined
- its main risks are known

## Catastrophes MVP done means:
- trigger from risk
- active state persisted
- effect applied over time
- alert emitted
- region reflects consequences
- restart preserves correct state
